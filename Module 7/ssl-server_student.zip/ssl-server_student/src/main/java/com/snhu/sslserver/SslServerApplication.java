package com.snhu.sslserver;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}
//FIXED: Add route to enable check sum return of static data example:  String data = "Hello World Check Sum!";

@RestController
class ServerController {
	
	// store the primitive data
	private static final byte[] HEX_ARRAY = "0123456789ABCDEF".getBytes(StandardCharsets.US_ASCII);
	
	private String generateChecksum(String data) {
        try {
        	// secure one-way hash functions for data using SHA-256
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            
             // Generate a hash value of byte type from data
            byte[] hash = digest.digest(data.getBytes(StandardCharsets.UTF_8));
            return bytesToHex(hash);
            
          // Handles exceptions and errors
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }
	
	// Convert the hash value to hex using the bytesToHex function
	public static String bytesToHex(byte[] bytes) {
	    byte[] hexChars = new byte[bytes.length * 2];
	    for (int j = 0; j < bytes.length; j++) {
	        int v = bytes[j] & 0xFF;
	        hexChars[j * 2] = HEX_ARRAY[v >>> 4];
	        hexChars[j * 2 + 1] = HEX_ARRAY[v & 0x0F];
	    }
	    return new String(hexChars, StandardCharsets.UTF_8);
	}	
    
    // Generate and return the required data + hash to the web browser
    @RequestMapping("/hash")
    public String myHash() {
        String data = "Winnie Kwong Check Sum!";

        String checksum = generateChecksum(data);

        // Returns data and checksum
        return "<p>Data: " + data + "</p>" + "<p>Checksum: " + checksum + "</p>";
    }

}
